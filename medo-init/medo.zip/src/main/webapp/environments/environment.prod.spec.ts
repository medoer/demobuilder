import { environment } from './environment.prod';

describe('environment', () => {
  it('production should be true', () => {
    expect(environment.production).toBeTruthy();
  });
});
