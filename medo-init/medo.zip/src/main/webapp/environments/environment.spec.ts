import { environment } from './environment';

describe('environment', () => {
  it('production should be false', () => {
    expect(environment.production).toBeFalsy();
  });
});
