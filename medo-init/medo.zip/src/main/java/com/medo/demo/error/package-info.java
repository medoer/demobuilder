@com.medo.demo.SharedKernel
package com.medo.demo.error;
